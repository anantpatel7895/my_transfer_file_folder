package com.greatlearning.springdemo;

public class FootballCoach implements SportsCoach {

	@Override
	public String getTrainingSchedule() {

		return "Practice dribbling";
	}

}
