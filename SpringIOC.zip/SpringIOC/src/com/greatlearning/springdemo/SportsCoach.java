package com.greatlearning.springdemo;

public interface SportsCoach {

	public String getTrainingSchedule();
}
