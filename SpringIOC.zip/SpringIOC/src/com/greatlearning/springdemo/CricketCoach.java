package com.greatlearning.springdemo;

public class CricketCoach implements SportsCoach {

	@Override
	public String getTrainingSchedule() {

		return "Practice Straight Drive";
	}

}
