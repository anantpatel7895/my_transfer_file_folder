package com.greatlearning.springdemo.advices;

public interface ExpertAdvice {

	public String getAdvice();
}
