package com.greatlearning.springdemo.coaches;

public interface SportsCoach {

	public String getTrainingSchedule();
	
	public String getAdvice();
}
