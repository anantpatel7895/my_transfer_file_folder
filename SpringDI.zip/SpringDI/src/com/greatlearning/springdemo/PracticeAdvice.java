package com.greatlearning.springdemo;

public class PracticeAdvice implements ExpertAdvice {

	@Override
	public String getAdvice() {
		return "Do a lot of practice";
	}

}
