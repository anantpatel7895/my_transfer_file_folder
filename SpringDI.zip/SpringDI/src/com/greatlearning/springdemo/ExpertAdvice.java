package com.greatlearning.springdemo;

public interface ExpertAdvice {

	public String getAdvice();
}
